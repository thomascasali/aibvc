﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace API_Login_Registra.Models
{
    public class CredenzialiExtraTabella
    {
        public string ComuneNascita { get; set; }
        public string ComuneResidenza { get; set; }
        public string NomeSocieta { get; set; }
        public string Password { get; set; }
    }
}
