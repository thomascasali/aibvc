﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebAPIAuthJWT.Helpers;
using TEST.Models;
using API_Login_Registra.Models;

namespace API_Login_Registra.Controllers
{
    [ApiController]
    [Produces("application/json")]
    [Route("api/v1/registrati")]
    public class RegistraController : Controller
    {
        Database db = new Database();

        [HttpPost("RegistraAllenatore")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(InfoMsg))]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status422UnprocessableEntity)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public ActionResult<InfoMsg> RegisterAllenatore([FromBody] Allenatore allenatore, [FromBody] CredenzialiExtraTabella cred)
        {
            if (db.GetIDComuneNascita(cred.ComuneNascita).Rows.Count > 0 && db.GetIDComuneResidenza(cred.ComuneResidenza).Rows.Count > 0 && db.GetIDSocieta(cred.NomeSocieta).Rows.Count > 0)
            {
                allenatore.IDComuneNascita = db.GetIDComuneNascita(cred.ComuneNascita).Rows[0][0].ToString();
                allenatore.IDComuneResidenza = db.GetIDComuneResidenza(cred.ComuneResidenza).Rows[0][0].ToString();
                allenatore.IDSocieta = Convert.ToInt32(db.GetIDSocieta(cred.NomeSocieta).Rows[0][0]);
                if (db.RegisterAllenatore(allenatore.IDSocieta, allenatore.CodiceTessera, allenatore.Grado, allenatore.Nome, allenatore.Cognome, allenatore.Sesso, allenatore.CF, allenatore.DataNascita, allenatore.IDComuneNascita, allenatore.IDComuneResidenza, allenatore.Indirizzo, allenatore.CAP, allenatore.Email, allenatore.Tel, cred.Password))
                    return Ok(new InfoMsg(DateTime.Today, $"Inserimento dell'allenatore {allenatore.Nome} eseguito con successo."));
                else
                    return StatusCode(500, new InfoMsg(DateTime.Today, $"Errori in inserimento dell'allenatore {allenatore.Nome}."));
            }
            else
                return StatusCode(500, new InfoMsg(DateTime.Today, $"Errori in inserimento dell'allenatore {allenatore.Nome}."));
        }
        [HttpPost("RegistraAtleta")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(InfoMsg))]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status422UnprocessableEntity)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public ActionResult<InfoMsg> RegisterAtleta([FromBody] Atleta atleta, [FromBody] CredenzialiExtraTabella cred)
        {
            if (db.GetIDComuneNascita(cred.ComuneNascita).Rows.Count > 0 && db.GetIDComuneResidenza(cred.ComuneResidenza).Rows.Count > 0 && db.GetIDSocieta(cred.NomeSocieta).Rows.Count > 0)
            {
                atleta.IDComuneNascita = db.GetIDComuneNascita(cred.ComuneNascita).Rows[0][0].ToString();
                atleta.IDComuneResidenza = db.GetIDComuneResidenza(cred.ComuneResidenza).Rows[0][0].ToString();
                atleta.IDSocieta = Convert.ToInt32(db.GetIDSocieta(cred.NomeSocieta).Rows[0][0]);
                if (db.RegisterAtleta(atleta.IDSocieta,atleta.CodiceTessera,atleta.Nome,atleta.Cognome,atleta.Sesso,atleta.CF,atleta.DataNascita,atleta.IDComuneNascita,atleta.IDComuneResidenza,atleta.Indirizzo,atleta.CAP,atleta.Email,atleta.Tel,atleta.Altezza,atleta.Peso,atleta.DataScadenzaCertificato, cred.Password))
                    return Ok(new InfoMsg(DateTime.Today, $"Inserimento dell'atleta {atleta.Nome} eseguito con successo."));
                else
                    return StatusCode(500, new InfoMsg(DateTime.Today, $"Errori in inserimento dell'atleta {atleta.Nome}."));
            }
            else
                return StatusCode(500, new InfoMsg(DateTime.Today, $"Errori in inserimento dell'atleta {atleta.Nome}."));
        }
        [HttpPost("RegistraDelegato")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(InfoMsg))]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status422UnprocessableEntity)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public ActionResult<InfoMsg> RegisterDelegato([FromBody] DelegatoTecnico delegato, [FromBody] CredenzialiExtraTabella cred)
        {
            if(db.GetIDComuneNascita(cred.ComuneNascita).Rows.Count > 0 && db.GetIDComuneResidenza(cred.ComuneResidenza).Rows.Count > 0)
            {
                delegato.IDComuneNascita = db.GetIDComuneNascita(cred.ComuneNascita).Rows[0][0].ToString();
                delegato.IDComuneResidenza = db.GetIDComuneResidenza(cred.ComuneResidenza).Rows[0][0].ToString();
                if (db.RegisterDelegato(delegato.Nome, delegato.Cognome, delegato.Sesso, delegato.CF, delegato.DataNascita, delegato.IDComuneNascita, delegato.IDComuneResidenza, delegato.Indirizzo, delegato.CAP, delegato.Email, delegato.Tel, delegato.Arbitro, delegato.Supervisore, cred.Password))
                    return Ok(new InfoMsg(DateTime.Today, $"Inserimento del delegato {delegato.Nome} eseguito con successo."));
                else
                    return StatusCode(500, new InfoMsg(DateTime.Today, $"Errori in inserimento del delegato {delegato.Nome}."));
            }
            else
                return StatusCode(500, new InfoMsg(DateTime.Today, $"Errori in inserimento del delegato {delegato.Nome}."));
        }
        [HttpPost("RegistraSocieta")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(InfoMsg))]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status422UnprocessableEntity)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public ActionResult<InfoMsg> RegisterSocieta([FromBody] Societa societa, [FromBody] CredenzialiExtraTabella cred)
        {
            if (db.GetIDComuneResidenza(cred.ComuneResidenza).Rows.Count > 0)
            {
                societa.IDComune = db.GetIDComuneResidenza(cred.ComuneResidenza).Rows[0][0].ToString();
                if (db.RegisterSocieta(societa.IDComune, societa.NomeSocieta, societa.Indirizzo, societa.CAP, societa.DataFondazione, societa.DataAffiliazione, societa.CodiceAffiliazione, societa.Affiliata, societa.Email, societa.Sito, societa.Tel1, societa.Tel2, societa.Pec, societa.PIVA, societa.CF, societa.CU, cred.Password))
                    return Ok(new InfoMsg(DateTime.Today, $"Inserimento della societa {societa.NomeSocieta} eseguito con successo."));
                else
                    return StatusCode(500, new InfoMsg(DateTime.Today, $"Errori in inserimento della societa {societa.NomeSocieta}."));
            }
            else
                return StatusCode(500, new InfoMsg(DateTime.Today, $"Errori in inserimento della societa {societa.NomeSocieta}."));
        }
    }
}
